package com.example.flashcardforcodepath

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val flashcardQuestion = findViewById<TextView>(R.id.flashcard_question)
        val flashcardAnswer = findViewById<TextView>(R.id.flashcard_answer)
        val flashcardAns2=findViewById<TextView>(R.id.flashcard_answer2)
        val flashcardAns3=findViewById<TextView>(R.id.flashcard_answer3)
        val EYE=findViewById<ImageView>(R.id.eye)
        val DASHEDEYE=findViewById<ImageView>(R.id.dashedeye)
        flashcardAns2.setOnClickListener {
            flashcardAns2.setBackgroundColor(getResources().getColor(R.color.my_red_color, null))
            flashcardAnswer.setBackgroundColor(getResources().getColor(R.color.my_green_color, null))
        }
        flashcardAns3.setOnClickListener {
            flashcardAns3.setBackgroundColor(getResources().getColor(R.color.my_red_color, null))
            flashcardAnswer.setBackgroundColor(getResources().getColor(R.color.my_green_color, null))
        }
        flashcardAnswer.setOnClickListener {
            flashcardAnswer.setBackgroundColor(getResources().getColor(R.color.my_green_color, null))
        }
        EYE.setOnClickListener {
            if (flashcardAnswer.isShown) {
                flashcardAnswer.visibility = View.INVISIBLE
                flashcardAns2.visibility = View.INVISIBLE
                flashcardAns3.visibility = View.INVISIBLE
                DASHEDEYE.visibility = View.VISIBLE
                EYE.visibility = View.INVISIBLE
            }
        }
        DASHEDEYE.setOnClickListener {
            flashcardAns2.visibility=View.VISIBLE
            flashcardAnswer.visibility=View.VISIBLE
            flashcardAns3.visibility=View.VISIBLE
            EYE.visibility=View.VISIBLE
            DASHEDEYE.visibility=View.INVISIBLE
        }
    }
}